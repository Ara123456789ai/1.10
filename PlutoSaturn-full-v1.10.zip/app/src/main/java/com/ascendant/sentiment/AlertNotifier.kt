package com.ascendant.sentiment

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.ascendant.sentiment.engine.AstroEngine
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/** Runs every 15 minutes in the background and checks the coming hour for Saturn and Pluto entry windows. */
class AlertWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        try {
            AlertNotifier.check(applicationContext, System.currentTimeMillis())
        } catch (_: Exception) {
        }
        return Result.success()
    }
}

object AlertNotifier {
    private const val PREFS = "ps_prefs"
    private const val CHANNEL = "entry_alerts"
    private val ASC_WATCH = listOf(
        Triple("Saturn", listOf(120, 135, 150), 9101),
        Triple("Pluto", listOf(135), 9102),
        Triple("Mars", listOf(30, 45, 60), 9201),
        Triple("Venus", listOf(30, 45, 60), 9202),
        Triple("Sun", listOf(30, 45, 60, 90), 9203)
    )

    fun schedule(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<AlertWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("entry-alerts", ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    fun saveLocation(ctx: Context, lat: Double, lon: Double) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putLong("lat", java.lang.Double.doubleToRawLongBits(lat))
            .putLong("lon", java.lang.Double.doubleToRawLongBits(lon))
            .apply()
    }

    fun isEnabled(ctx: Context): Boolean = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("enabled", true)

    fun setEnabled(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("enabled", on).apply()
    }

    private fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Entry windows", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    private fun canNotify(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun post(ctx: Context, id: Int, title: String, text: String) {
        if (!canNotify(ctx)) return
        ensureChannel(ctx)
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (_: SecurityException) {
        }
    }

    fun sendTest(ctx: Context) {
        post(ctx, 9001, "Pluto–Saturn test", "Notifications are working. Entry windows will appear here.")
    }

    fun describe(a: com.ascendant.sentiment.model.EntryAlert, nowMs: Long): String {
        val glyph = if (a.target == "Saturn") "♄" else "♇"
        val hm = SimpleDateFormat("HH:mm", Locale.US)
        val span = hm.format(Date(a.firstMs)) + "–" + hm.format(Date(a.lastMs + 300_000L))
        val mins = ((a.firstMs - nowMs) / 60_000L).toInt()
        val when_ = if (a.activeNow || mins <= 0) "active now" else "in ~$mins min"
        return "Asc ${a.ascAngle}° $glyph with ☽ ${a.moonAngle}° $glyph · $span (phone time) · $when_"
    }

    fun check(ctx: Context, nowMs: Long) {
        if (!isEnabled(ctx)) return
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val lat = java.lang.Double.longBitsToDouble(prefs.getLong("lat", java.lang.Double.doubleToRawLongBits(51.5074)))
        val lon = java.lang.Double.longBitsToDouble(prefs.getLong("lon", java.lang.Double.doubleToRawLongBits(-0.1278)))
        val seen = LinkedHashSet(prefs.getStringSet("seen", emptySet()) ?: emptySet())
        var changed = false
        // Ascendant aspects to Saturn / Pluto / Mars / Venus / Sun: notify 15 minutes before they enter orb, only while the Sun activates the planet;
        // Saturn and Pluto are a STRONG entry when the Moon also aspects them (Saturn 60/90/120/135/150, Pluto 90/135)
        for ((planet, angles, id) in ASC_WATCH) {
            val moonAngles = when (planet) { "Saturn" -> listOf(60, 90, 120, 135, 150); "Pluto" -> listOf(90, 135); else -> emptyList() }
            val a = AstroEngine.ascAspectStart(nowMs, lat, lon, planet, angles, 60, moonAngles = moonAngles) ?: continue
            val leadMs = a.startMs - nowMs
            if (leadMs > 16 * 60_000L) {
                // too early: wake up again 15 minutes before the start
                val req = OneTimeWorkRequestBuilder<AlertWorker>().setInitialDelay(leadMs - 15 * 60_000L, TimeUnit.MILLISECONDS).build()
                WorkManager.getInstance(ctx).enqueueUniqueWork("pre-$planet", ExistingWorkPolicy.REPLACE, req)
                continue
            }
            val key = "asc|$planet|${a.angle}|${a.startMs / 60_000L}"
            if (key in seen) continue
            seen.add(key)
            changed = true
            val g = AstroEngine.PLANETS.first { it.name == planet }.glyph
            val mins = (leadMs / 60_000L).toInt().coerceAtLeast(1)
            val hm = SimpleDateFormat("HH:mm", Locale.US).format(Date(a.startMs))
            val sunPart = if (a.sunAngle >= 0) " · ☉ ${a.sunAngle}° $g active" else ""
            val strong = a.moonAngle >= 0
            val moonPart = (if (strong) " · ☽ ${a.moonAngle}° $g" else "") +
                (if (a.neutral >= 2) " · NEUTRALISED by ${a.neutralBy}" else if (a.neutral == 1) " · weakened by ${a.neutralBy}" else "")
            post(
                ctx, id,
                (if (strong) "$g $planet · STRONG entry, Asc ${a.angle}° in ~$mins min" else "$g $planet · Asc ${a.angle}° in ~$mins min"),
                "Asc ${a.angle}° $g enters orb at $hm (phone time)$sunPart$moonPart"
            )
        }
        if (changed) {
            val keep = seen.toList().takeLast(30).toSet()
            prefs.edit().putStringSet("seen", keep).apply()
        }
    }
}
